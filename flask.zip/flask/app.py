from flask import Flask, render_template
import sqlite3
import os

app = Flask(__name__)

# Absolute path to the database
DATABASE_PATH = os.path.join(os.getcwd(), 'transactions.db')

def init_db():
    """ Initialize the database and create table if it does not exist """
    conn = sqlite3.connect(DATABASE_PATH)
    cursor = conn.cursor()
    cursor.execute('''
    CREATE TABLE IF NOT EXISTS transactions (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        date TEXT,
        datetime TEXT,
        cash_type TEXT,
        card TEXT,
        money REAL,
        coffee_name TEXT
    )
    ''')
    conn.commit()
    conn.close()

@app.route('/')
def index():
    """ Route to serve the home page """
    return render_template('index.html')

@app.route('/about')
def about():
    """ Route to serve the about page """
    return render_template('about.html')

@app.route('/data')
def data():
    """ Route to serve the data page with transactions data """
    conn = sqlite3.connect(DATABASE_PATH)
    conn.row_factory = sqlite3.Row
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM transactions LIMIT 50")
    rows = cursor.fetchall()
    conn.close()
    return render_template('data.html', rows=rows)

if __name__ == '__main__':
    # Initialize the database and table before running the app
    init_db()
    app.run(debug=True)
