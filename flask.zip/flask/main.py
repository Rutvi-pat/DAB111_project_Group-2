import sqlite3
import pandas as pd

# Create or open a database named 'transactions.db'
conn = sqlite3.connect('transactions.db')
cursor = conn.cursor()

# Create the table
cursor.execute('''
CREATE TABLE IF NOT EXISTS transactions (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    date TEXT,
    datetime TEXT,
    cash_type TEXT,
    card TEXT,
    money REAL,
    coffee_name TEXT
)
''')

# Commit changes and close the connection
conn.commit()
conn.close()
